#include "tbMultipliers.h"

SC_MODULE_EXPORT(tbMultipliers);
